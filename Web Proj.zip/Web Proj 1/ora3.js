/*            <div class="flex-container">
            <strong class="flex-item" ondblclick="editText(this)">Item name:</strong>
            <span class="flex-item" ondblclick="editText(this)">Item info</span>
            <img class="delete-button" src="trashcan.png" style="width: 30px; height: 30px" alt="">
            </div>
            */

function addInfoItem(element){
    var count = element.childElementCount;
    var container = element.appendChild(document.createElement("div"));
    container.setAttribute("class", "flex-container");
    var itemName = container.appendChild(document.createElement("strong"));
    itemName.setAttribute("class", "flex-item");
    itemName.setAttribute("ondblclick", "editText(this)");
    itemName.innerText = "Item name:";
    var itemInfo = container.appendChild(document.createElement("span"));
    itemInfo.setAttribute("class", "flex-item");
    itemInfo.setAttribute("ondblclick", "editText(this)");
    itemInfo.innerText = "Item info";
    var deleteButton = container.appendChild(document.createElement("img"));
    deleteButton.setAttribute("class", "delete-button");
    deleteButton.setAttribute("src", "trashcan.png");
    deleteButton.setAttribute("style", "width: 30px; height: 30px");
    deleteButton.setAttribute("alt", "");
    deleteButton.setAttribute("onclick", "deleteItem(this)");


}
/*
        <form action="">
            <fieldset id="group1">
             <legend ><span ondblclick="editGroupText(this)" style="color: rgb(0, 70, 192);">Thông tin sinh viên_20210188 </span>
                <span onclick="addInfoItem(this.closest('fieldset'))" style="color: #1b1a1a;">< Add Info Item ></span>
                <span onclick="addGroupItem(this.closest('form'))" style="color: #1b1a1a;">< Add Group Item ></span>
            </legend>
            <br>
            <div class="flex-container">
            <strong class="flex-item" ondblclick="editText(this)">Item name:</strong>
            <span class="flex-item" ondblclick="editText(this)">Item info</span>
            </div>
            
             
            </fieldset>
           </form>
*/
function addGroupItem(element){
    var count = element.childElementCount;
    var fieldset = element.appendChild(document.createElement("fieldset"));
    var legend = fieldset.appendChild(document.createElement("legend"));
    legend.setAttribute("onclick", "");
    
    var legendText = legend.appendChild(document.createElement("span"));
    legendText.innerText = "Group Item_20210188";
    legendText.setAttribute("style", "color: rgb(0, 70, 192);");
    legendText.setAttribute("ondblclick", "editGroupText(this)");
    

    var deleteButton = legend.appendChild(document.createElement("img"));
    deleteButton.setAttribute("class", "delete-button");
    deleteButton.setAttribute("src", "trashcan.png");
    deleteButton.setAttribute("style", "width: 30px; height: 30px");
    deleteButton.setAttribute("alt", "");
    deleteButton.setAttribute("onclick", "deleteGroupItem(this)");

    var addInfoItemSpan = legend.appendChild(document.createElement("span"));
    addInfoItemSpan.setAttribute("onclick", "addInfoItem(this.closest('fieldset'))");
    addInfoItemSpan.setAttribute("style", "color: #1b1a1a;");
    addInfoItemSpan.innerText = "< Add Info Item >";
    var addGroupItemSpan = legend.appendChild(document.createElement("span"));
    addGroupItemSpan.setAttribute("onclick", "addGroupItem(this.closest('form'))");
    addGroupItemSpan.setAttribute("style", "color: #1b1a1a;");
    addGroupItemSpan.innerText = "< Add Group Item >";

}

function editText(element){
    var currentText = element.innerText;
    element.innerText = "";

    var input = element.appendChild(document.createElement("input"));
    input.type = "text";
    input.value = currentText;

    input.focus();
    input.select();

    input.addEventListener("keydown", function(e){
        if(e.key === "Enter"){
            element.innerText = input.value;
            element.removeChild(input);
        }
    });



}

function editGroupText(element){
    var currentText = element.innerText;
    element.innerText = "";

    var input = element.appendChild(document.createElement("input"));
    input.type = "text";
    input.value = currentText;

    input.focus();
    input.select();

    input.addEventListener("keydown", function(e){
        if(e.key === "Enter"){
            element.innerText = input.value;
            element.innerText += "_20210188";
            element.removeChild(input);
        }
    });
}

function deleteGroupItem(element){
    //Confirmation before deleting
    var result = confirm("Are you sure you want to delete this group? My name is Cao Huy Dong 20210188");
    if(result){
        element.parentElement.parentElement.remove();
    }
}


function deleteItem(element){
    element.parentElement.remove();
}
